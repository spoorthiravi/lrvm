#define trans_t long int
#include <string>
#include <vector>
#include <unordered_map>

using namespace std;
typedef struct Log{
	int logID;
	int logSize;

}log;
typedef struct Segment{
	char* segmentName;
	int segmentSize;
	void* segmentData;
	boolean mapped;
	vector<Log> logFiles;
}segment;
typedef struct rvm_t
{
int rvmID;
const char* directory;
vector<Segment> segmentList;
}rvm_t;